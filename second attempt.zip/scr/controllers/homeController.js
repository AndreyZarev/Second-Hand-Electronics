const router = require('express').Router();
const { isAuth } = require('../middleware/authMiddleware')
const createService = require('../services/createService');

router.get('/', (req, res) => {

    res.render("home")
})

router.get("/create", (req, res) => {

    res.render("create")

})


router.post('/create', async (req, res) => {
    const productData = req.body

    try {
        await createService.createPost(productData)

    }
    catch (err) {
        res.render("create", { err })
    }

});

router.get('/details', (req, res) => {
    res.render("details")
});

router.post("details", (req, res) => {

});




router.get('/catalog', async (req, res) => {
    const createdPost = await createService.getAllPosts().lean()

    res.render("catalog", { createdPost })


});


router.get('/search', (req, res) => {
    res.render("search")
});

router.post('/search', (req, res) => {
});



module.exports = router