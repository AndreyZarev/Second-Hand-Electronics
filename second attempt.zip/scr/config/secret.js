module.exports = {

    SECRET: "ciuahs63gd62vyag52vrybs7dg3dyasgyudg63t7svd6g2gy2gd"


}