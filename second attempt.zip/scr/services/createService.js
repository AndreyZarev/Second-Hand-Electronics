const Electronics = require('../models/Electronics')

exports.createPost = async function (productData) {

    await Electronics.create(productData)

}


exports.getAllPosts = () => {
    const allPosts = Electronics.find()
    return allPosts
}