const User = require("../models/User")


exports.register = async (userData) => {

    const user = await User.findOne({ email: userData.email })

    if (user) {
        throw new Error(`User already exists`);
    }

    if (userData.password !== userData.rePassword) {
        throw new Error("Passwords do not match!");
    }
    User.create(userData)
}