const router = require('express').Router();
const authService = require("../services/authService")


router.get('/register', (req, res) => {

    res.render('register');

})

router.post('/register', async (req, res) => {

    const userData = req.body

    try {
        await authService.register(userData)

        res.redirect("/auth/login")

    } catch (err) {
        res.render('register', { message: err.message });
    }

});


module.exports = router